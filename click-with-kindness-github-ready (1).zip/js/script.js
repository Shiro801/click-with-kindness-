const tabs=document.querySelectorAll('.tab');
const pages=document.querySelectorAll('.page');

function showPage(id){
  pages.forEach(p=>p.classList.toggle('active',p.id===id));
  tabs.forEach(t=>t.classList.toggle('active',t.dataset.page===id));
  window.scrollTo({top:0,behavior:'smooth'});
}
tabs.forEach(tab=>tab.addEventListener('click',()=>showPage(tab.dataset.page)));

function scenarioAnswer(choice){
  const r=document.getElementById('scenarioResult');
  r.classList.add('show');
  if(choice===3){
    r.innerHTML='<b>🌟 Peacebuilder response!</b><br>You chose not to participate, support the person affected, and seek responsible help. This reflects compassion, human dignity, and peacemaking.';
  }else{
    r.innerHTML='<b>💭 Think again.</b><br>This response can allow harm to continue or make the situation worse. A peacebuilder avoids joining the harm, supports the person affected, and seeks appropriate help.';
  }
}
function scenarioAnswer2(choice){
  const r=document.getElementById('scenarioResult2');
  r.classList.add('show');
  if(choice===2){
    r.innerHTML='<b>🌟 Peacebuilder response!</b><br>Refusing to share embarrassing content protects the person’s dignity and prevents the harm from spreading.';
  }else{
    r.innerHTML='<b>💭 Think again.</b><br>Sharing embarrassing content can spread harm. A peaceful response refuses to participate and encourages responsible action.';
  }
}

let pledges=Number(localStorage.getItem('kindnessPledges')||0);
document.getElementById('pledgeCount').textContent=pledges;
function takePledge(){
  const name=document.getElementById('pledgeName').value.trim();
  if(!name){alert('Please enter a first name or nickname.');return}
  pledges++;localStorage.setItem('kindnessPledges',pledges);
  document.getElementById('pledgeCount').textContent=pledges;
  document.getElementById('pledgeName').value='';
  alert('Thank you, '+name+'! 🕊️ You chose to be a peacemaker.');
}

function addNote(){
  const name=document.getElementById('wallName').value.trim()||'Anonymous';
  const msg=document.getElementById('wallMessage').value.trim();
  if(!msg){alert('Please write a kind message first.');return}
  const note=document.createElement('div');note.className='note';
  note.innerHTML=escapeHtml(msg)+'<strong>— '+escapeHtml(name)+'</strong>';
  document.getElementById('wallPosts').prepend(note);
  document.getElementById('wallName').value='';document.getElementById('wallMessage').value='';
}
function escapeHtml(str){
  return str.replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}

document.getElementById('surveyForm').addEventListener('submit',function(e){
  e.preventDefault();
  const data=new FormData(this);
  let score=0;
  ['q1','q2','q3'].forEach(q=>score+=Number(data.get(q)));
  const q4=data.get('q4'),q5=data.get('q5');
  const confidence=Math.round((score/12)*100);
  const actionText={support:'supporting someone affected',report:'reporting harmful behavior',refuse:'refusing to join or share harmful content',all:'using all of these actions'}[q4];
  const valueText={love:'love of neighbor',dignity:'human dignity',compassion:'compassion',justice:'justice'}[q5];
  const r=document.getElementById('surveyResult');
  r.classList.add('show');
  r.innerHTML='<div class="big-score">'+confidence+'%</div><h3>Your Cyber Peace Readiness Reflection</h3>'+
  '<p>Based on your answers, you showed awareness of cyberbullying and the importance of peaceful action. You identified <b>'+actionText+'</b> as an action you are willing to take, and <b>'+valueText+'</b> as a Christian value connected to peacemaking.</p>'+
  '<p><b>Personal challenge:</b> What is one specific action you can take this week to make your online community kinder?</p>';
});
function clearSurvey(){
  document.getElementById('surveyForm').reset();
  document.getElementById('surveyResult').classList.remove('show');
  document.getElementById('surveyResult').innerHTML='';
}
