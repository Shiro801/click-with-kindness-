# Click With Kindness 💗🕊️

**A Christian Peacebuilding Initiative about Cyberbullying**

> Think before you type. Choose kindness. Build peace.

Click With Kindness is a student-friendly interactive website created for a Christian peacebuilding activity focused on cyberbullying. It connects the social issue of cyberbullying with Christian faith, peacebuilding, and concrete action.

## ✨ Website Features

- 🏠 Home — campaign introduction and the Faith → Peace → Action flow
- 💻 Learn — what cyberbullying is, who is affected, common forms, effects, and a peacebuilding perspective
- ✝️ Faith & Peace — Matthew 5:9 and Christian values connected to digital behavior
- 🎭 Scenarios — interactive cyberbullying response situations
- 🕊️ Be a Peacemaker — the S.A.F.E. approach and a peace pledge
- 💌 Kindness Wall — visitors can post positive messages
- 📝 Survey — interactive cyber peace awareness/reflection survey
- 🌷 Resources — practical steps for responding to harmful online behavior

## 📁 Project Structure

```text
click-with-kindness-github/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── script.js
├── assets/
│   └── (reserved for images/icons if added later)
├── .gitignore
└── README.md
```

## 🚀 Run Locally

No server or framework is required.

1. Download or clone this repository.
2. Open `index.html` in a web browser.

The website uses Google Fonts through an external stylesheet, so an internet connection is recommended for the intended typography.

## 🌐 Publish with GitHub Pages

1. Create a new **public** GitHub repository.
2. Upload all files and folders from this project.
3. Make sure `index.html` is in the repository root.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose:
   - **Source:** Deploy from a branch
   - **Branch:** `main`
   - **Folder:** `/ (root)`
6. Save the settings.
7. GitHub will provide the published Pages URL.

## 📝 Important Note About the Survey and Kindness Wall

The current interactive features use the browser's JavaScript and `localStorage`.

That means:

- Survey results are calculated in the visitor's browser and are **not automatically collected into a central database**.
- Peace pledges are counted only on the device/browser where they are submitted.
- Kindness Wall posts are added to the current page and are not automatically shared with other visitors.

For a school demonstration, this keeps the site simple and does not require a backend. If shared survey data is needed later, the survey can be connected to a service such as Google Forms, Firebase, or another database.

## 🎨 Design

The website uses a pastel pink, blue, purple, white, and cream palette with rounded cards, soft shadows, responsive layouts, animations, and student-friendly illustrations made with HTML/CSS.

## 🕊️ Project Connection

The website follows the project's central flow:

**SOCIAL ISSUE → CHRISTIAN FAITH → PEACE → CONCRETE ACTION**

It encourages visitors to recognize cyberbullying, connect their online choices with Christian values, practice peaceful responses, and take concrete action.

## 📚 Main Scripture

> “Blessed are the peacemakers, for they shall be called children of God.”

**Matthew 5:9**

## 📄 License

This project is intended for educational/student use. You may adapt the code for your school peacebuilding project.
